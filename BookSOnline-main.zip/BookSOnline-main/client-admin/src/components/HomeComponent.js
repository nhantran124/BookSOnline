import React, { Component } from 'react';
class Home extends Component {
  
  render() {
    return (
      <div className="align-center">
        <h2 className="text-center mt-5">WELCOME TO ADMIN HOMEPAGE</h2>
        <img src="https://i.gifer.com/XOsX.gif" width="800px" height="600px" alt="" />
      </div>
    );
  }
}
export default Home;