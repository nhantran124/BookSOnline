const MyConstants = {
    DB_SERVER: 'BookSOnline.w14pp4b.mongodb.net',
    DB_USER: 'huatrungkien126',
    DB_PASS: 'kien19032002',
    DB_DATABASE: 'shoppeClone',
    EMAIL_USER: 'huatrungkien126@gmail.com', // Microsoft mail service
    EMAIL_PASS: 'lpoknwqknmmrdwgs',
    JWT_SECRET: '<jwt_secret>',
    JWT_EXPIRES: '3600000', // in milliseconds
};
module.exports = MyConstants;