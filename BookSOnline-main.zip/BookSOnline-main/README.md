# Gmail mail service
    EMAIL_USER: 'put your email here'
    EMAIL_PASS: 'password'
Vào link này https://security.google.com/settings/security/apppasswords
Chọn Khác (Tên tuỳ chỉnh) đặt tên cho nó là nodemailer sau đó bấm Tạo và nó sẽ ra 1 chuỗi password
copy và paste cái password vào chỗ EMAIL_PASS

![Screenshot](https://cdn.discordapp.com/attachments/942677514990518302/1118195395990933525/pass.png)
